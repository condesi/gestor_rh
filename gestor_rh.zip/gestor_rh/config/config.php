php

Copiar
<?php
defined('BASEPATH') or exit('No direct script access allowed');

$config['module_name'] = 'Gestor HR';
$config['module_version'] = '1.0.0';