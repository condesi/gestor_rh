php

Copiar
<?php
$lang['gestor_hr'] = 'Gestor de Recursos Humanos';
// Otros textos traducidos